<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * NatureOfGroups Model
 *
 * @property \App\Model\Table\AccountingGroupsTable|\Cake\ORM\Association\HasMany $AccountingGroups
 *
 * @method \App\Model\Entity\NatureOfGroup get($primaryKey, $options = [])
 * @method \App\Model\Entity\NatureOfGroup newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\NatureOfGroup[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\NatureOfGroup|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\NatureOfGroup saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\NatureOfGroup patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\NatureOfGroup[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\NatureOfGroup findOrCreate($search, callable $callback = null, $options = [])
 */
class NatureOfGroupsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('nature_of_groups');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->hasMany('AccountingGroups', [
            'foreignKey' => 'nature_of_group_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', 'create');

        $validator
            ->scalar('name')
            ->maxLength('name', 100)
            ->requirePresence('name', 'create')
            ->allowEmptyString('name', false);

        return $validator;
    }
}
